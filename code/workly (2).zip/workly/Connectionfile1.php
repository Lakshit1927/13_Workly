<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "users1";

$conn = new mysqli($servername, $username, $password ,$db);
 
?>